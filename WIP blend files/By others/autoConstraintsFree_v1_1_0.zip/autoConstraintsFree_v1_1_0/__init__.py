'''
Copyright (C) 2024 SpaghetMeNot All Rights Reserved

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

bl_info = {
    "name": "autoConstraints Free",
    "author": "SpaghetMeNot <spaghetmenot@gmail.com>",
    "blender": (4, 0, 0),
    "category": "Transform",
    "location": "View3D > Header",
    "description": "Automatically apply axis constraints to transform operations",
    "version": (1,1,0)
}

import bpy
import mathutils
from . import ac_keymaps, ac_operators, icons

# Reimport ac modules if blender has already started for development
if "bpy" in locals():
    import importlib
    importlib.reload(ac_operators)
    importlib.reload(ac_keymaps)
    importlib.reload(icons)


# Contexts the UI shows up in — this should pair with the 'keymap_names' variable in ac_keymaps.py
contexts = ['OBJECT']


class PREFERENCES_AutoConstraintsGetFullVersion(bpy.types.Operator):
    """Opens store page for full version"""
    bl_idname = "preferences.auto_constraints_get_full"
    bl_label = "Get Full Version"
    bl_description = "Opens link to full version of autoConstraints"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(self, context):
        return context.region.type == 'WINDOW'
    
    def execute(self, context):
        import webbrowser
        webbrowser.open('https://spaghetmenot.gumroad.com/l/autoconstraints')
        return {'FINISHED'}

class AutoConstraintsFreePreferences(bpy.types.AddonPreferences):
    """Addon Preferences for auto-constraints"""
    bl_idname = __name__

    def draw(self, context):
        layout = self.layout
        layout.operator('preferences.auto_constraints_get_full', icon='URL')

class AutoConstraintsFreeSettings(bpy.types.PropertyGroup):
    """Property Group for all auto-constraint scene properties"""
    autoconstraint_on: bpy.props.BoolProperty(
        name = 'Auto-constraints on',
        default = True,
        description = 'Toggle auto-constraint behaviour globally'
    )
    last_custom_orientation: bpy.props.StringProperty(
        name = 'Auto-constraint last custom orientation',
        default = "",
        description = 'Used to store the last used custom orientation so we can clean it up next transform (there is a crash if deleted with the current operator and then locking to an axis manually'
    )


def autoconstraint_toggle_button(self, context):
    """Draws the auto-constraint toggle in object mode"""
    if context.mode not in contexts:
        return
    ac_settings = context.scene.autoconstraints_free_settings
    layout = self.layout
    row = layout.row(align=True)
    icon_value = icons.icon_id('AC_ON') if ac_settings.autoconstraint_on else icons.icon_id('AC_OFF')
    row.prop(ac_settings, 'autoconstraint_on', text='', icon_value=icon_value)

    
# Used for registering and unregistering classes
blender_classes = [
    AutoConstraintsFreeSettings,
    PREFERENCES_AutoConstraintsGetFullVersion,
    AutoConstraintsFreePreferences,
]


def register():
    # Register operators
    ac_operators.register()
    icons.register()
    
    # Register classes
    for blender_class in blender_classes:
        bpy.utils.register_class(blender_class)
    
    # Register scene properties
    bpy.types.Scene.autoconstraints_free_settings = bpy.props.PointerProperty(type=AutoConstraintsFreeSettings)
    
    # Add toggle to both tool header
    bpy.types.VIEW3D_HT_tool_header.append(autoconstraint_toggle_button)

    # Register keymaps
    ac_keymaps.register()
    
    # Hack to make sure keymaps register (on restart Blender can sometimes not have access to user keymaps)
    bpy.app.timers.register(ac_keymaps.ensure_keymaps, first_interval=2.0)


def unregister():
    # Unregister operators
    ac_operators.unregister()
    icons.unregister()

    # Unregister properties
    del bpy.types.Scene.autoconstraints_free_settings
    
    # Unregister classes
    for blender_class in blender_classes:
        bpy.utils.unregister_class(blender_class)
    
    # Remove toggle from view_3d header
    bpy.types.VIEW3D_HT_header.remove(autoconstraint_toggle_button)
    bpy.types.VIEW3D_HT_tool_header.remove(autoconstraint_toggle_button)

    # Unregister keymaps
    ac_keymaps.unregister()